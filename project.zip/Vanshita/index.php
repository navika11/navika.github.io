<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="True Law Assosiation"/>
<meta name="keywords" content="adviser, attorney, bootstrap, business"/>
<meta name="author" content="ThemeMascot"/>


<!-- Page Title -->
<title>True Law Assosiations</title>

<!-- Favicon and Touch Icons -->
<link href="images/tomarlogo.jpg" rel="shortcut icon" type="image/png">
<link href="images/logo.png" rel="apple-touch-icon">
<link href="images/logo.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/logo.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/logo.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.min.css" rel="stylesheet" type="text/css">
<link href="css/javascript-plugins-bundle.css" rel="stylesheet"/>

<!-- CSS | menuzord megamenu skins -->
<link href="js/menuzord/css/menuzord.css" rel="stylesheet"/>

<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>

<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-color-set1.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.js"></script> 

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/javascript-plugins-bundle.js"></script>
<script src="js/menuzord/js/menuzord.js"></script>

<!-- REVOLUTION STYLE SHEETS -->
<link rel="stylesheet" type="text/css" href="js/revolution-slider/css/rs6.css">
<link rel="stylesheet" type="text/css" href="js/revolution-slider/extra-rev-slider1.css">
<!-- REVOLUTION LAYERS STYLES -->
<!-- REVOLUTION JS FILES -->
<script src="js/revolution-slider/js/revolution.tools.min.js"></script>
<script src="js/revolution-slider/js/rs6.min.js"></script>
<script src="js/revolution-slider/extra-rev-slider1.js"></script>

<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

</head>
<body class="tm-container-1300px has-side-panel side-panel-right">

<div id="boxes">
  <div id="dialog" class="window" style="text-align: justify">
  Welcome to the website of True Law Assosiation Current rules of the Bar Council of India impose restrictions on maintaining a web page and do not permit lawyers to provide information concerning their areas of practice. Tomar Lawyer’s is, therefore, constrained from providing any further information on this web page.<br>
The rules of the Bar Council of India prohibit law firms from soliciting work or advertising in any manner. By clicking on ‘I AGREE’, the user acknowledges that:<br>

1.	There has been no advertisement, personal communication, solicitation, invitation or any other inducement of any sort whatsoever by or on behalf of True Law Assosiation or any of its members to solicit any work through this website. <br>
2.	The user wishes to gain more information about True Law Assosiation, its practice areas and its attorneys, for his/her own information and use;<br>
3.	The information is made available/provided to the user only on his/her specific request and any information obtained or material downloaded from this website is completely at the user’s volition and any transmission, receipt or use of this site is not intended to, and will not, create any lawyer-client relationship; and<br>
4.	None of the information contained on the website is in the nature of a legal opinion or otherwise amounts to any legal advice.<br>
5.	True Law Assosiation, is not liable for any consequence of any action taken by the user relying on material/information provided under this website. In cases where the user has any legal issues, he/she in all cases must seek independent legal advice.<br>

    <div id="popupfoot"> <a href="#" class="close agree">I agree</a> | <a class="agree"style="color:red;" href="www.google.com">I do not agree</a> </div>
  </div>
  <div id="mask"></div>
</div>

<div class="side-panel-body-overlay"></div>

<div id="wrapper" class="clearfix">
  <!-- Header -->
  <?php include 'include/header.php';?>


  <!-- Start main-content -->
  <div class="main-content-area">

    <!-- Section: home Start -->
    <section id="home">
      <div class="container-fluid p-0">
        <div class="row">
          <div class="col">
            <!-- START Industrivo Rev Slider 2 REVOLUTION SLIDER 6.1.7 -->
            <p class="rs-p-wp-fix"></p>
            <rs-module-wrap id="rev_slider_1_1_wrapper" data-alias="industrivo-rev-slider-2" data-source="gallery" style="background:transparent;padding:0;margin:0px auto;margin-top:0;margin-bottom:0;">
              <rs-module id="rev_slider_1_1" style="display:none;" data-version="6.1.7">
                <rs-slides>
                  <rs-slide data-key="rs-9" data-title="Slide 1" data-thumb="images/bg/bg1.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/bg1.jpg" title="slide1" width="1920" height="1280" data-parallax="off" class="rev-slidebg" data-no-retina>
                    <rs-layer
                      id="slider-4-slide-9-layer-18"
                      data-type="text"
                      data-rsp_ch="on"
                      data-xy="x:l,l,l,c;xo:45px,45px,35px,0;yo:260px,203px,233px,212px;"
                      data-text="w:normal;s:120,93,92,68;l:115,89,90,68;ls:1px,0px,0px,0px;fw:700;a:left,left,left,center;"
                      data-frame_1="st:1000;sp:1000;sR:220;"
                      data-frame_999="o:0;st:w;sR:7790;"
                      style="z-index:9;"
                      class="font-current-theme2"
                      >Welcome to <br />
                      True Law Assosiation 
                    </rs-layer>
                    <rs-layer
                      id="slider-4-slide-9-layer-21"
                      data-type="text"
                      data-rsp_ch="on"
                      data-xy="x:l,l,l,c;xo:50px,50px,40px,0;yo:218px,170px,195px,169px;"
                      data-text="w:normal;s:22,22,21,20;l:25,19,23,22;ls:1px,0px,0px,0px;a:left,left,left,center;"
                      data-frame_1="st:500;sp:1000;"
                      data-frame_999="o:0;st:w;sR:8000;"
                      style="z-index:10;font-style:italic;"
                      class="font-current-theme2"
                      >We’re the best
                    </rs-layer>
                    <rs-layer
                      id="slider-4-slide-9-layer-22"
                      data-type="text"
                      data-rsp_ch="on"
                      data-xy="x:l,l,l,c;xo:50px,50px,40px,0;yo:540px,422px,448px,390px;"
                      data-text="w:normal;s:20,15,18,20;l:25,19,18,22;a:left,left,left,center;"
                      data-frame_1="st:1500;sp:1000;"
                      data-frame_999="o:0;st:w;sR:8700;"
                      style="z-index:8;"
                      ><a href="about.php" class="btn btn-flat btn-lg btn-theme-colored1 text-white">Discover More</a>
                    </rs-layer>
                    <rs-layer
                      id="slider-4-slide-9-layer-33"
                      data-type="shape"
                      data-rsp_ch="on"
                      data-text="w:normal;s:20,15,11,6;l:0,19,14,8;"
                      data-dim="w:100%;h:100%;"
                      data-basealign="slide"
                      data-frame_1="st:500;sp:1000;"
                      data-frame_999="o:0;st:w;sR:8000;"
                      style="z-index:3;background-color:rgba(0,0,0,0.5);"
                    >
                    </rs-layer>
                  </rs-slide>
                  <rs-slide data-key="rs-13" data-title="Slide 1" data-thumb="images/bg/bg2.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/bg2.jpg" title="slide2" width="1920" height="1280" data-parallax="off" class="rev-slidebg" data-no-retina>
                    <rs-layer
                      id="slider-4-slide-13-layer-18"
                      data-type="text"
                      data-rsp_ch="on"
                      data-xy="x:l,l,l,c;xo:45px,45px,35px,0;yo:260px,203px,233px,212px;"
                      data-text="w:normal;s:120,93,92,68;l:115,89,90,68;ls:1px,0px,0px,0px;fw:700;a:left,left,left,center;"
                      data-frame_1="st:1000;sp:1000;sR:220;"
                      data-frame_999="o:0;st:w;sR:7790;"
                      style="z-index:9; font-size: 63px"
                      class="font-current-theme2"
                      >The Right
                      Lawyer <br>
                    </rs-layer>
                    <rs-layer
                      id="slider-4-slide-13-layer-21"
                      data-type="text"
                      data-rsp_ch="on"
                      data-xy="x:l,l,l,c;xo:50px,50px,40px,0;yo:218px,170px,195px,169px;"
                      data-text="w:normal;s:22,22,21,20;l:25,19,23,22;ls:1px,0px,0px,0px;a:left,left,left,center;"
                      data-frame_1="st:500;sp:1000;"
                      data-frame_999="o:0;st:w;sR:8000;"
                      style="z-index:10;font-style:italic;"
                      class="font-current-theme2"
                      >Makes all the difference
                    </rs-layer>
                    <rs-layer
                      id="slider-4-slide-13-layer-22"
                      data-type="text"
                      data-rsp_ch="on"
                      data-xy="x:l,l,l,c;xo:50px,50px,40px,0;yo:540px,422px,448px,390px;"
                      data-text="w:normal;s:20,15,18,20;l:25,19,18,22;a:left,left,left,center;"
                      data-frame_1="st:1500;sp:1000;"
                      data-frame_999="o:0;st:w;sR:8700;"
                      style="z-index:8;"
                      >
                      <a href="about.php" class="btn btn-flat btn-lg btn-theme-colored1 text-white">Discover More</a>
                    </rs-layer>
                    <rs-layer
                      id="slider-4-slide-13-layer-33"
                      data-type="shape"
                      data-rsp_ch="on"
                      data-text="w:normal;s:20,15,11,6;l:0,19,14,8;"
                      data-dim="w:100%;h:100%;"
                      data-basealign="slide"
                      data-frame_1="st:500;sp:1000;"
                      data-frame_999="o:0;st:w;sR:8000;"
                      style="z-index:3;background-color:rgba(0,0,0,0.5);"
                    >
                    </rs-layer>
                  </rs-slide>
                  <rs-slide data-key="rs-15" data-title="Slide 1" data-thumb="images/bg/bg3.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:slotslide-horizontal;sl:d;">
                    <img src="images/bg/bg3.jpg" title="slide3" width="1920" height="1280" data-parallax="off" class="rev-slidebg" data-no-retina>
                    <rs-layer
                      id="slider-4-slide-15-layer-18"
                      data-type="text"
                      data-rsp_ch="on"
                      data-xy="x:l,l,l,c;xo:45px,45px,35px,0;yo:260px,203px,233px,212px;"
                      data-text="w:normal;s:120,93,92,68;l:115,89,90,68;ls:1px,0px,0px,0px;fw:700;a:left,left,left,center;"
                      data-frame_1="st:1000;sp:1000;sR:220;"
                      data-frame_999="o:0;st:w;sR:7790;"
                      style="z-index:9;"
                      class="font-current-theme2"
                      >I will fight for a <br>
                      Dismissal
                    </rs-layer>
                    <rs-layer
                      id="slider-4-slide-15-layer-21"
                      data-type="text"
                      data-rsp_ch="on"
                      data-xy="x:l,l,l,c;xo:50px,50px,40px,0;yo:218px,170px,195px,169px;"
                      data-text="w:normal;s:22,22,21,20;l:25,19,23,22;ls:1px,0px,0px,0px;a:left,left,left,center;"
                      data-frame_1="st:500;sp:1000;"
                      data-frame_999="o:0;st:w;sR:8000;"
                      style="z-index:10;font-style:italic;"
                      class="font-current-theme2"
                      >Protect your freedom
                    </rs-layer>
                    <rs-layer
                      id="slider-4-slide-15-layer-22"
                      data-type="text"
                      data-rsp_ch="on"
                      data-xy="x:l,l,l,c;xo:50px,50px,40px,0;yo:540px,422px,448px,390px;"
                      data-text="w:normal;s:20,15,18,20;l:25,19,18,22;a:left,left,left,center;"
                      data-frame_1="st:1500;sp:1000;"
                      data-frame_999="o:0;st:w;sR:8700;"
                      style="z-index:8;"
                      ><a href="about.php" class="btn btn-flat btn-lg btn-theme-colored1 text-white">Discover More</a>
                    </rs-layer>
                    <rs-layer
                      id="slider-4-slide-15-layer-33"
                      data-type="shape"
                      data-rsp_ch="on"
                      data-text="w:normal;s:20,15,11,6;l:0,19,14,8;"
                      data-dim="w:100%;h:100%;"
                      data-basealign="slide"
                      data-frame_1="st:500;sp:1000;"
                      data-frame_999="o:0;st:w;sR:8000;"
                      style="z-index:3;background-color:rgba(0,0,0,0.5);"
                    >
                    </rs-layer>
                  </rs-slide>
                </rs-slides>
                <rs-static-layers>
                  <!--
                    -->
                </rs-static-layers>
                <rs-progress class="rs-bottom" style="height: 5px; background: rgba(199,199,199,0.5);"></rs-progress>
              </rs-module>
              <script>
                if(typeof revslider_showDoubleJqueryError === "undefined") {
                  function revslider_showDoubleJqueryError(sliderID) {
                    var err = "<div class='rs_error_message_box'>";
                    err += "<div class='rs_error_message_oops'>Oops...</div>";
                    err += "<div class='rs_error_message_content'>";
                    err += "You have some jquery.js library include that comes after the Slider Revolution files js inclusion.<br>";
                    err += "To fix this, you can:<br>&nbsp;&nbsp;&nbsp; 1. Set 'Module General Options' -> 'Advanced' -> 'jQuery & OutPut Filters' -> 'Put JS to Body' to on";
                    err += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jQuery.js inclusion and remove it";
                    err += "</div>";
                    err += "</div>";
                    jQuery(sliderID).show().html(err);
                  }
                }
              </script>
            </rs-module-wrap>
            <!-- END REVOLUTION SLIDER -->
          </div>
        </div>
      </div>
    </section>
    <!-- Section: home End -->

    <!-- Section: About -->
    <section class="img-right-bottom" data-tm-bg-img="images/bg/bg30.jpg">
      <div class="container-fluid pt-0 pl-0">
        <div class="section-content">
          <div class="row">
            <div class="col-lg-12 col-xl-4">
              <div class="tm-sc-welcome-area">
                <div class="wa-thumb" data-tm-bg-img="images/about/2.jpg"></div>
                <div class="entry-content">
                  <div class="details">
                    <h6 class="subtitle font-current-theme1 text-white mt-0">Welcome to</h6>
                    <h2 class="title text-white">True Law Assosiation</h2>
                    <!-- <p class="text-white">Lorem ipsum is simply free ed quia  dolor sit atur adipiscing elit is nunc quis sed ligula porta quis nec magna neulla.</p> -->
                    <div class="tm-sc-icon-box icon-box icon-left iconbox-centered-in-responsive iconbox-theme-colored1 animate-icon-on-hover animate-icon-rotate-y bg-white mt-50 mt-md-30 p-20">
                      <div class="icon-box-wrapper">
                        <div class="icon-wrapper">
                          <a class="icon icon-type-font-icon icon-xl icon-default text-theme-colored1 mt-0 mb-0"> <i class="flaticon-law-judge-2"></i> </a>
                        </div>
                        <div class="icon-text">
                          <h2 class="icon-box-title mt-15">24</h2>
                          <div class="content">
                            <h5 class="font-current-theme1">Hours Assistance</h5>
                          </div>
                        </div>
                        <div class="clearfix"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-8 col-lg-6 col-xl-4">
              <div class="tm-sc-about-area">
                <div class="entry-content">
                  <div class="details">
                    <h6 class="aa-subtitle text-theme-colored1 font-current-theme1 mt-0 mb-0">about us</h6>
                    <h2 class="aa-title">We Fight Against Violence</h2>
                    <!-- <p>Lorem ipsum is simply free ed quia lipsum dolor sit atur adipiscing elit is nunc quis tellus sed ligula porta quis nec magna neulla.</p> -->
                    <div class="tm-sc-unordered-list list-style12">
                      <ul>
                        <li><a href="Domestic Violence.php">Domestic Violence</a></li>
                        <li><a href="Driving Crimes & DUI.php">Driving Crimes & DUI</a></li>
                        <li><a href="Administrative Hearings.php">Administrative Hearings</a></li>
                        <li><a href="Personal Injury.php">Personal Injury</a></li>
                        <li><a href="Law Professionals">Law Professionals</a></li>
                        <li><a href="Legal Methods.php">Legal Methods</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-lg-6 col-xl-3">
              <div class="tm-se-about-right-img text-center">
                <img class="mb-25" src="images/about/3.jpg" alt="3.jpg">
                <div class="thumb mt-10">
                  <img src="images/about/4.jpg" alt="4.jpg">
                  <div class="tm-sc-funfact funfact text-center">
                    <div class="funfact-icon"> <i class="flaticon-law-court-1" data-tm-font-size="4rem"></i></div>
                    <h2 class="counter">
                      <span class="animate-number" data-value="90%" data-animation-duration="1500">0</span>
                    </h2>
                    <p class="font-current-theme1 text-uppercase mt-20">Cases won</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Section: Practice -->
    <!-- <section class="" data-tm-bg-color="#f9f3f0">
      <div class="container" data-tm-padding-top="220px">
        <div class="section-title">
          <div class="row">
            <div class="col-md-8">
              <div class="mb-60">
                <div class="tm-sc-section-title section-title">
                  <div class="title-wrapper">
                    <h6 class="subtitle text-uppercase text-theme-colored1">Our Expertise</h6>
                    <h2 class="title">Our Practice Areas</h2>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-4">
              <div class="tm-sc-button text-right mt-10 d-none d-md-block d-sm-none mt-md-15">
                <a href="page-practice.html" target="_self" class="btn btn-theme-colored1">View all areas</a>
              </div>
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-md-6 col-lg-4 col-xl-3 p-0">
              <div class="tm-sc-practice-area">
                <div class="pa-thumb" data-tm-bg-img="images/recent-case/6.jpg"></div>
                <div class="entry-content">
                  <div class="details">
                    <div class="icon"><i class="flaticon-law-portfolio text-theme-colored1"></i></div>
                    <h4 class="title">Business Law</h4>
                    <p>There are so many of lorem ipsum but majority have suffered.</p>
                    <a href="page-practice-details.html" class="pa-btn"><i class="fa fa-arrow-right"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3 p-0">
              <div class="tm-sc-practice-area">
                <div class="pa-thumb" data-tm-bg-img="images/recent-case/6.jpg"></div>
                <div class="entry-content">
                  <div class="details">
                    <div class="icon"><i class="flaticon-law-siren-1 text-theme-colored1"></i></div>
                    <h4 class="title">Health Law</h4>
                    <p>There are so many of lorem ipsum but majority have suffered.</p>
                    <a href="page-practice-details.html" class="pa-btn"><i class="fa fa-arrow-right"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3 p-0">
              <div class="tm-sc-practice-area">
                <div class="pa-thumb" data-tm-bg-img="images/recent-case/6.jpg"></div>
                <div class="entry-content">
                  <div class="details">
                    <div class="icon"><i class="flaticon-law-courthouse text-theme-colored1"></i></div>
                    <h4 class="title">Real Estate Law</h4>
                    <p>There are so many of lorem ipsum but majority have suffered.</p>
                    <a href="page-practice-details.html" class="pa-btn"><i class="fa fa-arrow-right"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3 p-0">
              <div class="tm-sc-practice-area">
                <div class="pa-thumb" data-tm-bg-img="images/recent-case/6.jpg"></div>
                <div class="entry-content">
                  <div class="details">
                    <div class="icon"><i class="flaticon-law-money-bag text-theme-colored1"></i></div>
                    <h4 class="title">Tax Law</h4>
                    <p>There are so many of lorem ipsum but majority have suffered.</p>
                    <a href="page-practice-details.html" class="pa-btn"><i class="fa fa-arrow-right"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3 p-0">
              <div class="tm-sc-practice-area">
                <div class="pa-thumb" data-tm-bg-img="images/recent-case/6.jpg"></div>
                <div class="entry-content">
                  <div class="details">
                    <div class="icon"><i class="flaticon-law-lawyer-1 text-theme-colored1"></i></div>
                    <h4 class="title">Civil Law</h4>
                    <p>There are so many of lorem ipsum but majority have suffered.</p>
                    <a href="page-practice-details.html" class="pa-btn"><i class="fa fa-arrow-right"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3 p-0">
              <div class="tm-sc-practice-area">
                <div class="pa-thumb" data-tm-bg-img="images/recent-case/6.jpg"></div>
                <div class="entry-content">
                  <div class="details">
                    <div class="icon"><i class="flaticon-law-judge-5 text-theme-colored1"></i></div>
                    <h4 class="title">Education Law</h4>
                    <p>There are so many of lorem ipsum but majority have suffered.</p>
                    <a href="page-practice-details.html" class="pa-btn"><i class="fa fa-arrow-right"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3 p-0">
              <div class="tm-sc-practice-area">
                <div class="pa-thumb" data-tm-bg-img="images/recent-case/6.jpg"></div>
                <div class="entry-content">
                  <div class="details">
                    <div class="icon"><i class="flaticon-law-footprint text-theme-colored1"></i></div>
                    <h4 class="title">Criminal Law</h4>
                    <p>There are so many of lorem ipsum but majority have suffered.</p>
                    <a href="page-practice-details.html" class="pa-btn"><i class="fa fa-arrow-right"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4 col-xl-3 p-0">
              <div class="tm-sc-practice-area">
                <div class="pa-thumb" data-tm-bg-img="images/recent-case/6.jpg"></div>
                <div class="entry-content">
                  <div class="details">
                    <div class="icon"><i class="flaticon-law-hourglass text-theme-colored1"></i></div>
                    <h4 class="title">Labour Law</h4>
                    <p>There are so many of lorem ipsum but majority have suffered.</p>
                    <a href="page-practice-details.html" class="pa-btn"><i class="fa fa-arrow-right"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section> -->

    <!-- Section: Testimonial -->
    <!-- <section class="layer-overlay overlay-theme-colored2-9 bg-img-center" data-tm-bg-img="images/bg/bg1.jpg">
      <div class="container pt-0 pb-70">
        <div class="section-content">
          <div class="row">
            <div class="col-lg-12">
              <div class="tm-testimonial-carousel" data-tm-margin-top="-50px">
                <div class="tm-owl-carousel-1col" data-dots="true" data-autoplay="false" data-margin="10" data-loop="false">
                  <div class="item">
                    <div class="tm-sc-testimonial-item">
                      <div class="thumb"><img src="images/testimonials/1.jpg" alt="image"></div>
                      <div class="details">
                        <p class="text-white">This is due to their excellent service, competitive pricing and customer support. It’s throughly refresing to get such a personal touch.</p>
                        <h4 class="client text-theme-colored1 mb-0">- Christine Eve</h4>
                      </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="tm-sc-testimonial-item">
                      <div class="thumb"><img src="images/testimonials/1.jpg" alt="image"></div>
                      <div class="details">
                        <p class="text-white">This is due to their excellent service, competitive pricing and customer support. It’s throughly refresing to get such a personal touch.</p>
                        <h4 class="client text-theme-colored1 mb-0">- Christine Eve</h4>
                      </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="tm-sc-testimonial-item">
                      <div class="thumb"><img src="images/testimonials/1.jpg" alt="image"></div>
                      <div class="details">
                        <p class="text-white">This is due to their excellent service, competitive pricing and customer support. It’s throughly refresing to get such a personal touch.</p>
                        <h4 class="client text-theme-colored1 mb-0">- Christine Eve</h4>
                      </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="tm-sc-testimonial-item">
                      <div class="thumb"><img src="images/testimonials/1.jpg" alt="image"></div>
                      <div class="details">
                        <p class="text-white">This is due to their excellent service, competitive pricing and customer support. It’s throughly refresing to get such a personal touch.</p>
                        <h4 class="client text-theme-colored1 mb-0">- Christine Eve</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
         
        </div>
      </div>
    </section> -->
 <!-- <hr class="divider-horizontal-line border-theme-colored1">
          <div class="row pt-50 pb-0">
            <div class="col-md-12">
              <div class="tm-sc-clients tm-sc-clients-carousel owl-dots-light-skin owl-dots-center">
                <div class="owl-carousel owl-theme tm-owl-carousel-5col" data-autoplay="true" data-loop="true" data-duration="6000" data-smartspeed="300" data-margin="30" data-stagepadding="0" data-laptop="4">
                  <div class="item"> <a target="_blank" href="#"> <img src='images/clients/1.png' alt='Image' /> </a></div>
                  <div class="item"> <a target="_blank" href="#"> <img src='images/clients/1.png' alt='Image' /> </a></div>
                  <div class="item"> <a target="_blank" href="#"> <img src='images/clients/1.png' alt='Image' /> </a></div>
                  <div class="item"> <a target="_blank" href="#"> <img src='images/clients/1.png' alt='Image' /> </a></div>
                  <div class="item"> <a target="_blank" href="#"> <img src='images/clients/1.png' alt='Image' /> </a></div>
                </div>
              </div>
            </div>
          </div> -->
    <!-- Section: Case Story -->
    <section class="bg-img-cover bg-img-center" data-tm-bg-img="images/bg/bg29.jpg">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-lg-12 col-xl-6">
              <div class="mb-35">
                <div class="case-story">
                  <div class="title-wrapper">
                    <h6 class="subtitle text-uppercase text-theme-colored1 font-current-theme1">Expert advise</h6>
                    <h2 class="title mt-0 mb-40">Tell us your Case Story We certainly Can Help You</h2>
                    <p class="mb-20">We are ready to help you if we know your case story.</p>
                    <div class="row mt-50 mb-50 align-items-center">
                      <div class="col-sm-3 col-md-3 col-lg-3">
                        <div class="tm-sc-pie-chart">
                          <div class="pie-chart"
                              data-bar-color="#e1bba6"
                              data-track-color="#fff"
                              data-scale-color="#8224e3"

                              data-scale-length="8"
                              data-line-cap="round"
                              data-line-width="3"
                              data-size="140"
                              data-tm-width="140"
                              data-tm-height="140"

                              data-percent="95">
                              <span class="percent font-current-theme2 font-weight-bold" data-tm-font-size="28px"></span>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-3 col-md-3 col-lg-3 text-center text-md-left">
                        <h4 class="chart-title mb-sm-30">Clients Satisfied</h4>
                      </div>
                      <div class="col-sm-3 col-md-3 col-lg-3 pl-sm-0">
                        <div class="tm-sc-pie-chart">
                          <div class="pie-chart"
                              data-bar-color="#e1bba6"
                              data-track-color="#fff"
                              data-scale-color="#8224e3"

                              data-scale-length="8"
                              data-line-cap="round"
                              data-line-width="3"
                              data-size="140"
                              data-tm-width="140"
                              data-tm-height="140"

                              data-percent="65">
                              <span class="percent font-current-theme2 font-weight-bold" data-tm-font-size="28px"></span>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-3 col-md-3 col-lg-3 pr-0 pl-sm-0 text-center text-md-left">
                        <h4 class="chart-title">Cases Disposed off</h4>
                      </div>
                    </div>
                    <div class="row mb-lg-30">
                      <div class="col-sm-6 col-md-6 col-lg-6">
                        <ul class="tm-ae-list list-unstyled">
                          <li><span class="fa fa-arrow-right mr-10"></span> Advocates with experience.</li>
                          <li><span class="fa fa-arrow-right mr-10"></span> Professional lawyers with expertise.</li>
                        </ul>
                      </div>
                      <div class="col-sm-6 col-md-6 col-lg-6">
                        <ul class="tm-ae-list list-unstyled">
                          <li><span class="fa fa-arrow-right mr-10"></span> We appear when you can’t.</li>
                          <li><span class="fa fa-arrow-right mr-10"></span> You will need the top lawyers.</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12 col-xl-5 offset-xl-1 pl-10">
              <div class="mb-35">
                <div class="case-story">
                  <div class="tm-content">
                    <img class="img-fullwidth" src="images/recent-case/7.jpg" alt="images">
                    <div class="caq-details">
                      <p>Call to ask question</p>
                      <h3 class="title text-theme-colored1"><a href="tel:+91-7065030001">+91-7065030001</a><br><a href="tel:+91-8826030001">+91-8826030001</a></h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Section: Pricing Table -->
    <!-- <section class="bg-white-f9">
      <div class="container pb-60">
        <div class="section-title">
          <div class="row justify-content-md-center">
            <div class="col-md-8">
              <div class="text-center mb-60">
                <div class="tm-sc-section-title section-title section-title-style1 text-center line-bottom-style4-attached-double-lines1">
                  <div class="title-wrapper">
                    <h6 class="subtitle text-uppercase text-theme-colored1">Case Solved</h6>
                    <h2 class="title">Pay Invoice Online</h2>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="tm-sc-nav-tabs-pricing nav-tab-btn-button button-rounded">
          <ul class="nav nav-tabs">
            <li class="active"> <a class="active show" href="#pricing-navtab-button-rounded1" data-bs-toggle="tab"> <span class="title">Monthly</span></a></li>
            <li class=""> <a class="" href="#pricing-navtab-button-rounded2" data-bs-toggle="tab"> <span class="title">Yearly</span> <span class="subtitle">20% Off</span></a></li>
          </ul>
          <div class="tab-content">
            <div class="tab-pane fadeInLeft in active show" id="pricing-navtab-button-rounded1">
              <div class="tab-pane-inner">
                <div class="row">
                  <div class="col-md-4">
                    <div class="tm-sc-pricing-table pricing-table-style-basic pricing-table-box-shadow pricing-table-hover-effect mb-30 text-center">
                      <div class="pricing-table-inner-wrapper">
                        <div class="pricing-table-inner">
                          <div class="pricing-table-head">
                            <div class="pricing-table-pricing"><span class="pricing-table-prefix">$</span> <span class="pricing-table-price" >49</span> <span class="pricing-table-separator">/</span> <span class="pricing-table-postfix">Monthly</span></div>
                            <div class="pricing-table-title-area">
                              <h4 class="pricing-table-title">Small Business</h4>
                            </div>
                          </div>
                          <div class="pricing-table-content">
                            <ul class="">
                              <li>Extra features</li>
                              <li>Lifetime free support</li>
                              <li>Upgrate options</li>
                              <li>Full access</li>
                            </ul>
                          </div>
                          <div class="pricing-table-footer">
                            <div class="btn-view-details">
                              <a href="#" target="_self" class="btn btn-theme-colored2 btn-round">Select Plan</a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="tm-sc-pricing-table pricing-table-style-basic pricing-table-box-shadow pricing-table-hover-effect mb-30 text-center">
                      <div class="pricing-table-inner-wrapper">
                        <div class="pricing-table-inner">
                          <div class="pricing-table-head">
                            <div class="pricing-table-pricing"><span class="pricing-table-prefix">$</span> <span class="pricing-table-price" >57</span> <span class="pricing-table-separator">/</span> <span class="pricing-table-postfix">Monthly</span></div>
                            <div class="pricing-table-title-area">
                              <h4 class="pricing-table-title">Large Business</h4>
                            </div>
                          </div>
                          <div class="pricing-table-content">
                            <ul class="">
                              <li>Extra features</li>
                              <li>Lifetime free support</li>
                              <li>Upgrate options</li>
                              <li>Full access</li>
                            </ul>
                          </div>
                          <div class="pricing-table-footer">
                            <div class="btn-view-details">
                              <a href="#" target="_self" class="btn btn-theme-colored2 btn-round">Select Plan</a>
                            </div>
                          </div>
                          <span class="pricing-table-label">Popular</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="tm-sc-pricing-table pricing-table-style-basic pricing-table-box-shadow pricing-table-hover-effect mb-30 text-center">
                      <div class="pricing-table-inner-wrapper">
                        <div class="pricing-table-inner">
                          <div class="pricing-table-head">
                            <div class="pricing-table-pricing"><span class="pricing-table-prefix">$</span> <span class="pricing-table-price" >84</span> <span class="pricing-table-separator">/</span> <span class="pricing-table-postfix">Monthly</span></div>
                            <div class="pricing-table-title-area">
                              <h4 class="pricing-table-title">Medium Business</h4>
                            </div>
                          </div>
                          <div class="pricing-table-content">
                            <ul class="">
                              <li>Extra features</li>
                              <li>Lifetime free support</li>
                              <li>Upgrate options</li>
                              <li>Full access</li>
                            </ul>
                          </div>
                          <div class="pricing-table-footer">
                            <div class="btn-view-details">
                              <a href="#" target="_self" class="btn btn-theme-colored2 btn-round">Select Plan</a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="tab-pane fadeInRight" id="pricing-navtab-button-rounded2">
              <div class="tab-pane-inner">
                <div class="row">
                  <div class="col-md-4">
                    <div class="tm-sc-pricing-table pricing-table-style-basic pricing-table-box-shadow pricing-table-hover-effect mb-30 text-center">
                      <div class="pricing-table-inner-wrapper">
                        <div class="pricing-table-inner">
                          <div class="pricing-table-head">
                            <div class="pricing-table-pricing"><span class="pricing-table-prefix">$</span> <span class="pricing-table-price" >149</span> <span class="pricing-table-separator">/</span> <span class="pricing-table-postfix">Monthly</span></div>
                            <div class="pricing-table-title-area">
                              <h4 class="pricing-table-title">Small Business</h4>
                            </div>
                          </div>
                          <div class="pricing-table-content">
                            <ul class="">
                              <li>Extra features</li>
                              <li>Lifetime free support</li>
                              <li>Upgrate options</li>
                              <li>Full access</li>
                            </ul>
                          </div>
                          <div class="pricing-table-footer">
                            <div class="btn-view-details">
                              <a href="#" target="_self" class="btn btn-theme-colored2 btn-round">Select Plan</a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="tm-sc-pricing-table pricing-table-style-basic pricing-table-box-shadow pricing-table-hover-effect mb-30 text-center">
                      <div class="pricing-table-inner-wrapper">
                        <div class="pricing-table-inner">
                          <div class="pricing-table-head">
                            <div class="pricing-table-pricing"><span class="pricing-table-prefix">$</span> <span class="pricing-table-price" >157</span> <span class="pricing-table-separator">/</span> <span class="pricing-table-postfix">Monthly</span></div>
                            <div class="pricing-table-title-area">
                              <h4 class="pricing-table-title">Large Business</h4>
                            </div>
                          </div>
                          <div class="pricing-table-content">
                            <ul class="">
                              <li>Extra features</li>
                              <li>Lifetime free support</li>
                              <li>Upgrate options</li>
                              <li>Full access</li>
                            </ul>
                          </div>
                          <div class="pricing-table-footer">
                            <div class="btn-view-details">
                              <a href="#" target="_self" class="btn btn-theme-colored2 btn-round">Select Plan</a>
                            </div>
                          </div>
                          <span class="pricing-table-label">Popular</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="tm-sc-pricing-table pricing-table-style-basic pricing-table-box-shadow pricing-table-hover-effect mb-30 text-center">
                      <div class="pricing-table-inner-wrapper">
                        <div class="pricing-table-inner">
                          <div class="pricing-table-head">
                            <div class="pricing-table-pricing"><span class="pricing-table-prefix">$</span> <span class="pricing-table-price" >184</span> <span class="pricing-table-separator">/</span> <span class="pricing-table-postfix">Monthly</span></div>
                            <div class="pricing-table-title-area">
                              <h4 class="pricing-table-title">Medium Business</h4>
                            </div>
                          </div>
                          <div class="pricing-table-content">
                            <ul class="">
                              <li>Extra features</li>
                              <li>Lifetime free support</li>
                              <li>Upgrate options</li>
                              <li>Full access</li>
                            </ul>
                          </div>
                          <div class="pricing-table-footer">
                            <div class="btn-view-details">
                              <a href="#" target="_self" class="btn btn-theme-colored2 btn-round">Select Plan</a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section> -->

    <!-- Section: Recent Case-->
    <!-- <section>
      <div class="container-fluid pb-80">
        <div class="section-title">
          <div class="row justify-content-md-center">
            <div class="col-md-8">
              <div class="text-center mb-60">
                <div class="tm-sc-section-title section-title section-title-style1 text-center line-bottom-style4-attached-double-lines1">
                  <div class="title-wrapper">
                    <h6 class="subtitle text-uppercase text-theme-colored1">Case Solved</h6>
                    <h2 class="title">Recent Case Studies</h2>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <div class="isotope-layout grid-5 gutter-10 clearfix">
                <div class="isotope-layout-inner">
              
                  <div class="isotope-item">
                    <div class="isotope-item-inner">
                      <div class="tm-sc-recent-case">
                        <div class="post-thumb">
                          <div class="thumb">
                            <img class="img-fullwidth" src="images/recent-case/1.jpg" alt="Image"/>
                          </div>
                        </div>
                        <div class="entry-content">
                          <div class="details">
                            <h4 class="title">Family Law</h4>
                            <p>There are so many of lorem ipsum but majority have suffered.</p>
                          </div>
                          <a href="page-case-details.html" class="btn rc-btn text-center bg-theme-colored1 bg-hover-theme-colored2"><i class="fa fa-arrow-right"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
               
                  <div class="isotope-item">
                    <div class="isotope-item-inner">
                      <div class="tm-sc-recent-case">
                        <div class="post-thumb">
                          <div class="thumb">
                            <img class="img-fullwidth" src="images/recent-case/2.jpg" alt="Image"/>
                          </div>
                        </div>
                        <div class="entry-content">
                          <div class="details">
                            <h4 class="title">Accident Injuries</h4>
                            <p>There are so many of lorem ipsum but majority have suffered.</p>
                          </div>
                          <a href="page-case-details.html" class="btn rc-btn text-center bg-theme-colored1 bg-hover-theme-colored2"><i class="fa fa-arrow-right"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
             
                  <div class="isotope-item">
                    <div class="isotope-item-inner">
                      <div class="tm-sc-recent-case">
                        <div class="post-thumb">
                          <div class="thumb">
                            <img class="img-fullwidth" src="images/recent-case/3.jpg" alt="Image"/>
                          </div>
                        </div>
                        <div class="entry-content">
                          <div class="details">
                            <h4 class="title">Business Law</h4>
                            <p>There are so many of lorem ipsum but majority have suffered.</p>
                          </div>
                          <a href="page-case-details.html" class="btn rc-btn text-center bg-theme-colored1 bg-hover-theme-colored2"><i class="fa fa-arrow-right"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
             
                  <div class="isotope-item">
                    <div class="isotope-item-inner">
                      <div class="tm-sc-recent-case">
                        <div class="post-thumb">
                          <div class="thumb">
                            <img class="img-fullwidth" src="images/recent-case/4.jpg" alt="Image"/>
                          </div>
                        </div>
                        <div class="entry-content">
                          <div class="details">
                            <h4 class="title">Civil Litigation</h4>
                            <p>There are so many of lorem ipsum but majority have suffered.</p>
                          </div>
                          <a href="page-case-details.html" class="btn rc-btn text-center bg-theme-colored1 bg-hover-theme-colored2"><i class="fa fa-arrow-right"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
               
                  <div class="isotope-item">
                    <div class="isotope-item-inner">
                      <div class="tm-sc-recent-case">
                        <div class="post-thumb">
                          <div class="thumb">
                            <img class="img-fullwidth" src="images/recent-case/5.jpg" alt="Image"/>
                          </div>
                        </div>
                        <div class="entry-content">
                          <div class="details">
                            <h4 class="title">Criminal Law</h4>
                            <p>There are so many of lorem ipsum but majority have suffered.</p>
                          </div>
                          <a href="page-case-details.html" class="btn rc-btn text-center bg-theme-colored1 bg-hover-theme-colored2"><i class="fa fa-arrow-right"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section> -->

    <!-- Section: News & Updates-->
    <!-- <section>
      <div class="container pt-0">
        <div class="section-title">
          <div class="row justify-content-md-center">
            <div class="col-md-8">
              <div class="text-center mb-60">
                <div class="tm-sc-section-title section-title section-title-style1 text-center line-bottom-style4-attached-double-lines1">
                  <div class="title-wrapper">
                    <h6 class="subtitle text-uppercase text-theme-colored1">News & Articles</h6>
                    <h2 class="title">Our Recent Blog Post</h2>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="section-content pb-20">
          <div class="row">
            <div class="col-md-6 col-lg-6 col-xl-4">
              <div class="tm-sc-blog tm-sc-blog-masonry blog-style1-current-theme mb-lg-30">
                <article class="post type-post status-publish format-standard has-post-thumbnail">
                  <div class="entry-header">
                    <div class="post-thumb lightgallery-lightbox">
                      <div class="post-thumb-inner">
                        <div class="thumb">
                          <img class="img-fullwidth" src="images/blog/b1.jpg" alt="Image"/>
                          <div class="date bg-theme-colored1 text-center text-uppercase">20 april</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="entry-content text-center">
                    <div class="entry-meta mt-0 pt-0 mb-0">
                      <span class="mb-10 text-gray-darkgray mr-10"><i class="fa fa-user mr-10 text-theme-colored"></i> Admin</span>
                      <span class="mb-10 text-gray-darkgray mr-10"><i class="fa fa-comment mr-10 text-theme-colored"></i> 2 Comments</span>
                    </div>
                    <h4 class="entry-title"><a href="news-details.html" rel="bookmark">How you can choose the best personal injury lawyers</a></h4>
                    <div class="post-excerpt">
                      <div class="mascot-post-excerpt">Lorem ipsum is simply free text used by new pesnhl note this copytyping refreshing.</div>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="post-btn-readmore text-center"> <a href="news-details.html" class="btn btn-block"> <span class="fa fa-arrow-right"></span> </a></div>
                </article>
              </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-4">
              <div class="tm-sc-blog tm-sc-blog-masonry blog-style1-current-theme mb-lg-30">
                <article class="post type-post status-publish format-standard has-post-thumbnail">
                  <div class="entry-header">
                    <div class="post-thumb lightgallery-lightbox">
                      <div class="post-thumb-inner">
                        <div class="thumb">
                          <img class="img-fullwidth" src="images/blog/b2.jpg" alt="Image"/>
                          <div class="date bg-theme-colored1 text-center text-uppercase">20 april</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="entry-content text-center">
                    <div class="entry-meta mt-0 pt-0 mb-0">
                      <span class="mb-10 text-gray-darkgray mr-10"><i class="fa fa-user mr-10 text-theme-colored"></i> Admin</span>
                      <span class="mb-10 text-gray-darkgray mr-10"><i class="fa fa-comment mr-10 text-theme-colored"></i> 2 Comments</span>
                    </div>
                    <h4 class="entry-title"><a href="news-details.html" rel="bookmark">We are the Best Lawyers in Our Town</a></h4>
                    <div class="post-excerpt">
                      <div class="mascot-post-excerpt">Lorem ipsum is simply free text used by new pesnhl note this copytyping refreshing.</div>
                    </div>
                  </div>
                  <div class="post-btn-readmore text-center"> <a href="news-details.html" class="btn btn-block"> <span class="fa fa-arrow-right"></span> </a></div>
                </article>
              </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-4">
              <div class="tm-sc-blog tm-sc-blog-masonry blog-style1-current-theme">
                <article class="post type-post status-publish format-standard has-post-thumbnail">
                  <div class="entry-header">
                    <div class="post-thumb lightgallery-lightbox">
                      <div class="post-thumb-inner">
                        <div class="thumb">
                          <img class="img-fullwidth" src="images/blog/b3.jpg" alt="Image"/>
                          <div class="date bg-theme-colored1 text-center text-uppercase">20 april</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="entry-content text-center">
                    <div class="entry-meta mt-0 pt-0 mb-0">
                      <span class="mb-10 text-gray-darkgray mr-10"><i class="fa fa-user mr-10 text-theme-colored"></i> Admin</span>
                      <span class="mb-10 text-gray-darkgray mr-10"><i class="fa fa-comment mr-10 text-theme-colored"></i> 2 Comments</span>
                    </div>
                    <h4 class="entry-title"><a href="news-details.html" rel="bookmark">Can choose the best personal injury lawyers</a></h4>
                    <div class="post-excerpt">
                      <div class="mascot-post-excerpt">Lorem ipsum is simply free text used by new pesnhl note this copytyping refreshing.</div>
                    </div>
                  </div>
                  <div class="post-btn-readmore text-center"> <a href="news-details.html" class="btn btn-block"> <span class="fa fa-arrow-right"></span> </a></div>
                </article>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section> -->
    
    <!-- end main-content -->
    <section class="bg-theme-colored1">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-xl-9">
            <div class="cta-content">
              <h2 class="text-white mt-0" data-tm-font-size="3rem">Are you looking for a consultation?</h2>
            </div>
          </div>
          <div class="col-lg-4 col-xl-3">
            <div class="cta-content">
              <a class="btn cta-btn btn-dark mt-10" href="contact.php" target="_self">Book an Appointment</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <!-- Footer -->
  <?php include 'include/footer.php';?>
 
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->
<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>


<script>
$(document).ready(function() {	

var id = '#dialog';
	
//Get the screen height and width
var maskHeight = $(document).height();
var maskWidth = $(window).width();
	
//Set heigth and width to mask to fill up the whole screen
$('#mask').css({'width':maskWidth,'height':maskHeight});

//transition effect
$('#mask').fadeIn(500);	
$('#mask').fadeTo("slow",0.9);	
	
//Get the window height and width
var winH = $(window).height();
var winW = $(window).width();
              
//Set the popup window to center
$(id).css('top',  winH/2-$(id).height()/2);
$(id).css('left', winW/2-$(id).width()/2);
	
//transition effect
$(id).fadeIn(2000); 	
	
//if close button is clicked
$('.window .close').click(function (e) {
//Cancel the link behavior
e.preventDefault();

$('#mask').hide();
$('.window').hide();
});

//if mask is clicked
$('#mask').click(function () {
$(this).hide();
$('.window').hide();
});
	
});
</script>
<!-- Modal -->
</body>
</html>