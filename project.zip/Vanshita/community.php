<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="True Law Assosiation"/>
<meta name="keywords" content="adviser, attorney, bootstrap, business"/>
<meta name="author" content="ThemeMascot"/>

<!-- Page Title -->
<title>True Law Assosiation</title>

<!-- Favicon and Touch Icons -->
<link href="images/tomarlogo.jpg" rel="shortcut icon" type="image/png">
<link href="images/logo.png" rel="apple-touch-icon">
<link href="images/logo.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/logo.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/logo.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.min.css" rel="stylesheet" type="text/css">
<link href="css/javascript-plugins-bundle.css" rel="stylesheet"/>

<!-- CSS | menuzord megamenu skins -->
<link href="js/menuzord/css/menuzord.css" rel="stylesheet"/>

<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>

<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-color-set1.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/javascript-plugins-bundle.js"></script>
<script src="js/menuzord/js/menuzord.js"></script>

<!-- REVOLUTION STYLE SHEETS -->
<link rel="stylesheet" type="text/css" href="js/revolution-slider/css/rs6.css">
<link rel="stylesheet" type="text/css" href="js/revolution-slider/extra-rev-slider1.css">
<!-- REVOLUTION LAYERS STYLES -->
<!-- REVOLUTION JS FILES -->
<script src="js/revolution-slider/js/revolution.tools.min.js"></script>
<script src="js/revolution-slider/js/rs6.min.js"></script>
<script src="js/revolution-slider/extra-rev-slider1.js"></script>

<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body class="tm-container-1300px has-side-panel side-panel-right">
<div class="side-panel-body-overlay"></div>

<div id="wrapper" class="clearfix">
  <!-- Header -->
  <?php include 'include/header.php';?>

  <!-- Start main-content -->
  <div class="main-content-area">
    <!-- Section: inner-header Start -->
    <section class="page-title divider layer-overlay overlay-dark-9 section-typo-light bg-img-center" data-tm-bg-img="images/bg/bg1.jpg">
      <div class="container pt-90 pb-90">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">COMMUNITY / PRO-BONO</h2>
              <nav role="navigation" class="breadcrumb-trail breadcrumbs">
                <div class="breadcrumbs">
                  <span class="trail-item trail-begin">
                    <a href="index.php"><span>Home</span></a>
                  </span>
                  <!-- <span><i class="fa fa-angle-right"></i></span> -->
                  <!-- <span class="trail-item"><a href="#"><span>Pages</span></a></span> -->
                  <span><i class="fa fa-angle-right"></i></span>
                  <span class="trail-item trail-end text-theme-colored1">COMMUNITY / PRO-BONO</span>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Section: inner-header End -->

    <!-- Section: Team Details -->
    <section>
      <div class="container pb-60">
        <div class="section-content">
          <div class="row">
            <div class="col-lg-3">
              <div class="sidebar">
                <div class="widget widget_text text-center">
                  <img src="images/team/team-details.jpg" class="img-fullwidth" alt=""/>
                </div>
                <div class="widget widget_text text-center">
                  <div class="textwidget">
                    <div class="section-typo-light bg-theme-colored1 mb-md-40 p-30 pt-40 pb-40"> <img class="size-full wp-image-800 aligncenter" src="images/headphone-128.png" alt="" width="128" height="128" />
                    <h4>Online Help!</h4>
                    <h5><a href="tel: +91-7065030001">+91-7065030001</a><br>
                    <a href="tel: +91-8826030001">+91-8826030001</a></h5>
                    </div>
                  </div>
                </div>
                <!-- <div class="widget p-30 bg-white-f5">
                  <h4 class="widget-title widget-title-line-bottom line-bottom-theme-colored1">Quick Contact!</h4>
                  <form id="quick_contact_form1" name="footer_quick_contact_form" class="quick-contact-form" action="http://html.thememascot.net/2020/business/zelwn/zelwn-html/includes/quickcontact.php" method="post">
                    <div class="mb-3">
                      <input name="form_email" class="form-control" type="text" placeholder="Enter Email">
                    </div>
                    <div class="mb-3">
                      <textarea name="form_message" class="form-control" required placeholder="Enter Message" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                      <input name="form_botcheck" class="form-control" type="hidden" value="" />
                      <button type="submit" class="btn btn-theme-colored1 btn-round" data-loading-text="Please wait...">Send Message</button>
                    </div>
                  </form>

        
                  <script>
                    (function($) {
                      $("#quick_contact_form1").validate({
                        submitHandler: function(form) {
                          var form_btn = $(form).find('button[type="submit"]');
                          var form_result_div = '#form-result';
                          $(form_result_div).remove();
                          form_btn.before('<div id="form-result" class="alert alert-success" role="alert" style="display: none;"></div>');
                          var form_btn_old_msg = form_btn.html();
                          form_btn.html(form_btn.prop('disabled', true).data("loading-text"));
                          $(form).ajaxSubmit({
                            dataType:  'json',
                            success: function(data) {
                              if( data.status === 'true' ) {
                                $(form).find('.form-control').val('');
                              }
                              form_btn.prop('disabled', false).html(form_btn_old_msg);
                              $(form_result_div).html(data.message).fadeIn('slow');
                              setTimeout(function(){ $(form_result_div).fadeOut('slow') }, 6000);
                            }
                          });
                        }
                      });
                    })(jQuery);
                  </script>
                </div> -->
              </div>
            </div>
            <div class="col-lg-9">
              <h3 class="mt-0 mb-10">Pro bono activities are an important professional responsibility.</h3>
              <p class="lead">True Law Assosiation also consider pro bono activities to be an important professional responsibility. True Law Assosiation strongly encourages all attorneys and paralegals to commit at least 120 hours per year to some type of pro bono activity. True Law Assosiation recognizes that efforts devoted to pro bono legal services, and the cause in question, may vary greatly from afvocate to advocate. The time spent on approved pro bono work is credited toward each advocates or each paralegal's annual performance goals and, therefore, it is considered, along with time devoted to client matters, for purposes of evaluation and compensation.</p>
              <p>These Pro Bono legal services include:</p>
              <h5>Poverty Law:</h5>
              <p>Legal services in civil or criminal matters of importance to a client who does not have the financial resources to pay a customary legal fee.</p>
              <h5>Civil Rights and Public Rights Law:</h5>
              <p>Legal services concerning rights of individuals, or a significant segment of the public as a whole, where it is inappropriate to charge the client a customary legal fee.</p>
              <h5>Representation of Charitable Organizations:</h5>
              <p>Legal services to charitable, religious, civic, governmental, educational, or similar organizations that provide services to the poor.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->

  <!-- Footer -->
  <?php include 'include/footer.php';?>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>
</html>
