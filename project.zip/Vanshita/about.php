<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="True Law Assosiation"/>
<meta name="keywords" content="adviser, attorney, bootstrap, business"/>
<meta name="author" content="ThemeMascot"/>

<!-- Page Title -->
<title>True Law Assosiation</title>

<!-- Favicon and Touch Icons -->
<link href="images/tomarlogo.jpg" rel="shortcut icon" type="image/png">
<link href="images/logo.png" rel="apple-touch-icon">
<link href="images/logo.png" rel="apple-touch-icon" sizes="72x72">
<link href="images/logo.png" rel="apple-touch-icon" sizes="114x114">
<link href="images/logo.png" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.min.css" rel="stylesheet" type="text/css">
<link href="css/javascript-plugins-bundle.css" rel="stylesheet"/>

<!-- CSS | menuzord megamenu skins -->
<link href="js/menuzord/css/menuzord.css" rel="stylesheet"/>

<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>

<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-color-set1.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/javascript-plugins-bundle.js"></script>
<script src="js/menuzord/js/menuzord.js"></script>

<!-- REVOLUTION STYLE SHEETS -->
<link rel="stylesheet" type="text/css" href="js/revolution-slider/css/rs6.css">
<link rel="stylesheet" type="text/css" href="js/revolution-slider/extra-rev-slider1.css">
<!-- REVOLUTION LAYERS STYLES -->
<!-- REVOLUTION JS FILES -->
<script src="js/revolution-slider/js/revolution.tools.min.js"></script>
<script src="js/revolution-slider/js/rs6.min.js"></script>
<script src="js/revolution-slider/extra-rev-slider1.js"></script>

<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body class="tm-container-1300px has-side-panel side-panel-right">
<div class="side-panel-body-overlay"></div>

<div id="wrapper" class="clearfix">
  <!-- Header -->
  <?php include 'include/header.php';?>

  <!-- Start main-content -->
  <div class="main-content-area">
    <!-- Section: inner-header Start -->
    <section class="page-title divider layer-overlay overlay-dark-9 section-typo-light bg-img-center" data-tm-bg-img="images/bg/bg1.jpg">
      <div class="container pt-90 pb-90">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title text-white">About Us</h2>
              <nav role="navigation" class="breadcrumb-trail breadcrumbs">
                <div class="breadcrumbs">
                  <span class="trail-item trail-begin">
                    <a href="index.php"><span>Home</span></a>
                  </span>
                  <span><i class="fa fa-angle-right"></i></span>
                  <!-- <span class="trail-item"><a href="#"><span>Pages</span></a></span>
                  <span><i class="fa fa-angle-right"></i></span> -->
                  <span class="trail-item trail-end text-theme-colored1">About Us</span>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Section: inner-header End -->

    <!-- Section: About -->
    <section class="bg-img-cover" data-tm-bg-img="images/bg/bg31.jpg">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="mb-lg-50 col-xl-6 col-md-12">
              <div class="case-story pr-30">
                <div class="title-wrapper">
                  <h6 class="subtitle text-uppercase text-theme-colored1 font-current-theme1">Best attorney firm</h6>
                  <h2 class="title mt-0">An Unjust Law is Not a Law at All</h2>
                  <p class="mb-20">True Law Assosiation is one of the fastest-growing full-service law firm in Delhi & NCR and has followed—if not created—the blueprint for legal success: True Law Assosiation is well-positioned to meet the legal needs of dynamic businesses and the individuals  who own and operate them.</p>
                  <div class="row">
                    <div class="col-md-6 col-lg-6">
                      <h5 class="mt-15 font-current-theme2"><i class="fa fa-long-arrow-right text-theme-colored1"></i> We Only Do Justice</h5>
                      <p>At True Law Assosiation we recognize one straightforward fact “Our Clients Care” less about our internal workings and more about the degree to which we understand their business, their industry, and the trends and challenges that can affect their ability to minimize risk and maximize success. This strong external focus and the diverse experience of more than 100 Advocates enable us to help clients solve problems, achieve opportunities and deal efficiently and effectively with an ever-changing economic, business and legal landscape.</p>
                    </div>
                    <div class="col-md-6 col-lg-6">
                      <h5 class="mt-15 font-current-theme2"><i class="fa fa-long-arrow-right text-theme-colored1"></i> We Fight for Justice</h5>
                      <p>Wherever your industry, True Law Assosiation is the better way to protect your business, preserve your family’s wealth and resolve your most challenging legal conflicts. At True Law Assosiation, we distinguish ourselves by our quality and breadth of legal services—as well as our unique operational structure, which encourages a culture of collaboration and entrepreneurialism. The same approach that makes our firm attractive to legal practitioners also gives clients access to experienced counsel in every area of the law.</p>
                    </div>
                  </div>
                  <div class="tm-sc-button d-none d-md-block d-sm-none mt-md-15">
                    <a href="contact.php" target="_self" class="btn btn-theme-colored1 text-uppercase">Learn More</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-6 col-md-12 pr-0 pl-0">
              <div class="tm-sc-about-our-video">
                <div class="thumb">
                  <img class="img-fullwidth" src="images/about/6.jpg" alt="image">
                </div>
                <div class="entry-content">
                  <!-- <a class="hover-link play-btn bg-theme-colored1" data-lightbox-gallery="youtube-video" href="https://www.youtube.com/mcvqOUtcAJg" title=""><span class="fa fa-play"></span></a> -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Section: Practice -->
    <!-- <section class="" data-tm-bg-color="#f9f3f0">
      <div class="container">
        <div class="section-title">
          <div class="row">
            <div class="col-md-12">
              <div class="mb-60">
                <div class="tm-sc-section-title section-title text-center">
                  <div class="title-wrapper">
                    <h6 class="subtitle text-uppercase text-theme-colored1">Our Expertise</h6>
                    <h2 class="title">Our Practice Areas</h2>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-lg-12">
              <div class="tm-practice-area-slider">
                <div class="tm-owl-carousel-4col" data-dots="true" data-autoplay="false" data-margin="10" data-loop="true">
                  <div class="item">
                    <div class="tm-gallery box-hover-effect">
                      <div class="effect-wrapper">
                        <div class="thumb ">
                          <img class="img-fullwidth" src="images/recent-case/p1.jpg" alt="image">
                          <div class="d-none">
                            <a href="#"></a>
                            <a href="#"></a>
                          </div>
                        </div>
                        <div class="overlay-shade shade-theme-colored2"></div>
                        <div class="icons-holder icons-holder-middle">
                          <div class="icons-holder-inner">
                            <div class="styled-icons icon-dark">
                              <a class="lightgallery-trigger styled-icons-item" href="page-practice-details.html" title="Gallery 1" data-exthumbimage="images/recent-case/p1.jpg" data-src="images/recent-case/p1.jpg">
                                <i class="fa fa-plus"></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="text-holder text-center">
                        <h4 class="title mt-20">Business Law</h4>
                      </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="tm-gallery box-hover-effect">
                      <div class="effect-wrapper">
                        <div class="thumb ">
                          <img class="img-fullwidth" src="images/recent-case/p2.jpg" alt="image">
                          <div class="d-none">
                            <a href="#"></a>
                            <a href="#"></a>
                          </div>
                        </div>
                        <div class="overlay-shade shade-theme-colored2"></div>
                        <div class="icons-holder icons-holder-middle">
                          <div class="icons-holder-inner">
                            <div class="styled-icons icon-dark">
                              <a class="lightgallery-trigger styled-icons-item" href="page-practice-details.html" title="Gallery 1" data-exthumbimage="images/recent-case/p2.jpg" data-src="images/recent-case/p2.jpg">
                                <i class="fa fa-plus"></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="text-holder text-center">
                        <h4 class="title mt-20">Health Law</h4>
                      </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="tm-gallery box-hover-effect">
                      <div class="effect-wrapper">
                        <div class="thumb ">
                          <img class="img-fullwidth" src="images/recent-case/p3.jpg" alt="image">
                          <div class="d-none">
                            <a href="#"></a>
                            <a href="#"></a>
                          </div>
                        </div>
                        <div class="overlay-shade shade-theme-colored2"></div>
                        <div class="icons-holder icons-holder-middle">
                          <div class="icons-holder-inner">
                            <div class="styled-icons icon-dark">
                              <a class="lightgallery-trigger styled-icons-item" href="page-practice-details.html" title="Gallery 1" data-exthumbimage="images/recent-case/p3.jpg" data-src="images/recent-case/p3.jpg">
                                <i class="fa fa-plus"></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="text-holder text-center">
                        <h4 class="title mt-20">Real Estate Law</h4>
                      </div>
                    </div>
                  </div>
                  <div class="item">
                    <div class="tm-gallery box-hover-effect">
                      <div class="effect-wrapper">
                        <div class="thumb ">
                          <img class="img-fullwidth" src="images/recent-case/p4.jpg" alt="image">
                          <div class="d-none">
                            <a href="#"></a>
                            <a href="#"></a>
                          </div>
                        </div>
                        <div class="overlay-shade shade-theme-colored2"></div>
                        <div class="icons-holder icons-holder-middle">
                          <div class="icons-holder-inner">
                            <div class="styled-icons icon-dark">
                              <a class="lightgallery-trigger styled-icons-item" href="page-practice-details.html" title="Gallery 1" data-exthumbimage="images/recent-case/p4.jpg" data-src="images/recent-case/p4.jpg">
                                <i class="fa fa-plus"></i>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="text-holder text-center">
                        <h4 class="title mt-20">Education Law</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section> -->

    <!-- Section: Call Us Area -->
    <section class="layer-overlay overlay-theme-colored2-9 bg-img-center" data-tm-bg-img="images/bg/bg1.jpg">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-lg-12">
              <div class="call-us">
                <div class="tm-sc-call-us text-center">
                  <div class="tm-sc-icon-box icon-box text-center iconbox-centered-in-responsive iconbox-theme-colored1 animate-icon-on-hover animate-icon-rotate mb-30">
                    <div class="icon-box-wrapper">
                      <div class="icon-wrapper">
                        <a class="icon icon-gray icon-xl">
                          <i class="fa fa-phone"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                  <h6 class="subtitle text-white text-uppercase">You want to discuss case in detail</h6>
                  <h2 class="title text-white mb-50">Call Us Our Lawyers Will Assist You</h2>
                  <h2 class="phone-number text-theme-colored1 font-current-theme1"><a href="tel:+91-7065030001">+91-7065030001</a><br><a href="tel:+91-8826030001">+91-8826030001</a></h2>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Section: Recent Case-->
    <section>
      <div class="container-fluid pb-80">
        <div class="section-title">
          <div class="row justify-content-md-center">
            <div class="col-md-8">
              <div class="text-center mb-60">
                <div class="tm-sc-section-title section-title section-title-style1 text-center line-bottom-style4-attached-double-lines1">
                  <div class="title-wrapper">
                    <h6 class="subtitle text-uppercase text-theme-colored1">Case Solved</h6>
                    <h2 class="title">Recent Case Studies</h2>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <div class="isotope-layout grid-5 gutter-10 clearfix">
                <div class="isotope-layout-inner">
                  <!-- the loop -->
                  <!-- Isotope Item Start -->
                  <div class="isotope-item">
                    <div class="isotope-item-inner">
                      <div class="tm-sc-recent-case">
                        <div class="post-thumb">
                          <div class="thumb">
                            <img class="img-fullwidth" src="images/recent-case/1.jpg" alt="Image"/>
                          </div>
                        </div>
                        <div class="entry-content">
                          <div class="details">
                            <h4 class="title">Family Law</h4>
                            <!-- <p>There are so many of lorem ipsum but majority have suffered.</p> -->
                          </div>
                          <!-- <a href="page-case-details.html" class="btn rc-btn text-center bg-theme-colored1 bg-hover-theme-colored2"><i class="fa fa-arrow-right"></i></a> -->
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- Isotope Item End -->

                  <!-- Isotope Item Start -->
                  <div class="isotope-item">
                    <div class="isotope-item-inner">
                      <div class="tm-sc-recent-case">
                        <div class="post-thumb">
                          <div class="thumb">
                            <img class="img-fullwidth" src="images/recent-case/2.jpg" alt="Image"/>
                          </div>
                        </div>
                        <div class="entry-content">
                          <div class="details">
                            <h4 class="title">Accident Injuries</h4>
                            <!-- <p>There are so many of lorem ipsum but majority have suffered.</p> -->
                          </div>
                          <!-- <a href="page-case-details.html" class="btn rc-btn text-center bg-theme-colored1 bg-hover-theme-colored2"><i class="fa fa-arrow-right"></i></a> -->
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- Isotope Item End -->

                  <!-- Isotope Item Start -->
                  <div class="isotope-item">
                    <div class="isotope-item-inner">
                      <div class="tm-sc-recent-case">
                        <div class="post-thumb">
                          <div class="thumb">
                            <img class="img-fullwidth" src="images/recent-case/3.jpg" alt="Image"/>
                          </div>
                        </div>
                        <div class="entry-content">
                          <div class="details">
                            <h4 class="title">Business Law</h4>
                            <!-- <p>There are so many of lorem ipsum but majority have suffered.</p> -->
                          </div>
                          <!-- <a href="page-case-details.html" class="btn rc-btn text-center bg-theme-colored1 bg-hover-theme-colored2"><i class="fa fa-arrow-right"></i></a> -->
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- Isotope Item End -->

                  <!-- Isotope Item Start -->
                  <div class="isotope-item">
                    <div class="isotope-item-inner">
                      <div class="tm-sc-recent-case">
                        <div class="post-thumb">
                          <div class="thumb">
                            <img class="img-fullwidth" src="images/recent-case/4.jpg" alt="Image"/>
                          </div>
                        </div>
                        <div class="entry-content">
                          <div class="details">
                            <h4 class="title">Civil Litigation</h4>
                            <!-- <p>There are so many of lorem ipsum but majority have suffered.</p> -->
                          </div>
                          <!-- <a href="page-case-details.html" class="btn rc-btn text-center bg-theme-colored1 bg-hover-theme-colored2"><i class="fa fa-arrow-right"></i></a> -->
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- Isotope Item End -->

                  <!-- Isotope Item Start -->
                  <div class="isotope-item">
                    <div class="isotope-item-inner">
                      <div class="tm-sc-recent-case">
                        <div class="post-thumb">
                          <div class="thumb">
                            <img class="img-fullwidth" src="images/recent-case/5.jpg" alt="Image"/>
                          </div>
                        </div>
                        <div class="entry-content">
                          <div class="details">
                            <h4 class="title">Criminal Law</h4>
                            <!-- <p>There are so many of lorem ipsum but majority have suffered.</p> -->
                          </div>
                          <!-- <a href="page-case-details.html" class="btn rc-btn text-center bg-theme-colored1 bg-hover-theme-colored2"><i class="fa fa-arrow-right"></i></a> -->
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- Isotope Item End -->
                  <!-- end of the loop -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->
  <!-- Footer -->
  <?php include 'include/footer.php';?>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>
</body>
</html>
